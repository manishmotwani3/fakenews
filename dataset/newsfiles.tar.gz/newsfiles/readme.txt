The first column contains labels for the type of news article:

1:"Satire",2:"Hoax",3:"Propaganda",4:"Trusted"